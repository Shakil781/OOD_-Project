import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        while (true) {
            Login_info l1 = new Login_info();

            System.out.println("Enter UserName : ");
            Scanner mc = new Scanner(System.in);
            String usname = mc.nextLine();
            System.out.println("Enter Your Passworod: ");
            String pas1 = mc.nextLine();
            l1.setU_name("Gm");
            l1.setPass("781");
            String xx = l1.getU_name();
            String yy = l1.getPass();
            int x = xx.compareTo(usname);
            int y = yy.compareTo(pas1);
            if (x == 0 && y == 0) {
                System.out.println("Login Successfully");
                System.out.println("1.view Product");
                System.out.println("2.Book product");
                System.out.println("3.Paymet Option");
                System.out.println("4.Logout");
                System.out.println("Choice??");
                int d = mc.nextInt();
            }
            else
            {
                System.out.println("Invalid password");
            }
        }
    }
}
