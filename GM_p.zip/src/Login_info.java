public class Login_info {
    private String u_name;
    private String pass;

    public String getU_name() {
        return u_name;
    }

    public void setU_name(String u_name) {
        this.u_name = u_name;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public void info()
    {
        System.out.println("Invalid pass");
    }
}
